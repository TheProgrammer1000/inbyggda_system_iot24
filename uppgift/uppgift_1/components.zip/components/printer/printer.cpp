#pragma once

#include <stdio.h>
#include "printer.h"
